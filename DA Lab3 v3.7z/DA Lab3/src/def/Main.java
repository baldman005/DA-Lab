package def;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Main {
	private static boolean ThreadAlive(ArrayList<Thread> t){
		for(int i=0; i<t.size(); i++)
			if(t.get(i).isAlive())
				return true;
		
		return false;
	}
	
	private static ArrayList<String> URLs = new ArrayList<String>();
	
	public static void main(String args[])   {
		int num_procs = 40;
		/*String rmi_name_0 = "rmi://145.94.187.205:1099/p1";
		String rmi_name_1 = "rmi://145.94.227.158:1100/p2";
		String rmi_name_2 = "rmi://145.94.187.205:1101/p3";
		*/
		
		for(int i=0; i<num_procs; i++)
			URLs.add("rmi://localhost:" + (1099+i) + "/p" + i);
		
		ArrayList<Thread> t = new ArrayList<Thread>();
		
		try {
			
		ArrayList<Process> p = new ArrayList<Process>();
		for(int i=0; i<num_procs; i++)
			p.add(new Process(i,num_procs,URLs));
		
		ArrayList<Registry> reg = new ArrayList<Registry>();
		for(int i=0; i<num_procs; i++)
			reg.add( java.rmi.registry.LocateRegistry.createRegistry(1099+i));
		
		for(int i=0; i<num_procs; i++)
			reg.get(i).bind(URLs.get(i), p.get(i));
		
		for(int i=0; i<num_procs; i++)
			java.rmi.Naming.bind(URLs.get(i), p.get(i));
	    
		for(int i=0; i<num_procs; i++){
			t.add(new Thread(p.get(i)));
			t.get(i).start();
		}
		
	    
	    while(ThreadAlive(t)) {
	    	Thread.sleep(500);
	    }
	    
	    Thread.sleep(2000);
	    
	    for(int i=0; i<num_procs; i++)
	    	reg.get(i).unbind(URLs.get(i));
	    
	    for(int i=0; i<num_procs; i++)
			UnicastRemoteObject.unexportObject(reg.get(i),true);

		} catch ( RemoteException| MalformedURLException| 
				AlreadyBoundException | NotBoundException  
				| InterruptedException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}
