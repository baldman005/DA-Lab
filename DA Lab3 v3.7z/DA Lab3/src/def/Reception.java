package def;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;

public interface Reception extends Remote {
	public void receive_message(Message m)throws java.rmi.RemoteException, InterruptedException, MalformedURLException, NotBoundException;

}
