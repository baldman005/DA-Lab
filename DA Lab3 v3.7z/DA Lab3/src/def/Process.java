package def;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Process extends UnicastRemoteObject implements Reception, Runnable {
	//PrintWriter writer;
	private int ts = 0;
	private int id;
	private static int num_procs;
	private ArrayList<Message> buffer = new ArrayList<Message>();
	private ArrayList<Message> deliveries = new ArrayList<Message>();
	private static ArrayList<String> URLs = new ArrayList<String>();
	private Candidate candidate;
	private Ordinary ordinary;
	private boolean election;
	private boolean elected;
	private int state = 0;

	//constructor
	protected Process(int id, int num_procs, ArrayList<String> URLs/*, String file*/) throws RemoteException {
		super(1099); //AQUI 1099?
		this.id=id;
		Process.num_procs=num_procs;
		Process.URLs=URLs;
		this.election=false;
		//this.writer = new PrintWriter("the-file-name.txt", "UTF-8");
	}
	
	//prints the buffer
	public void print_buffer(){
		System.out.println("Buffer " + this.id );
		for(Message e:this.buffer){
			e.print_message();
		}
	}
	
	
	//prints the acks
	
	//prints all the lists and timestamp

	


	//receive message
	@Override
	public  void receive_message(Message m) throws RemoteException, InterruptedException, MalformedURLException, NotBoundException {	
		buffer.add(m);
		return;
	}

	
	//broadcast message or ack
	public void broadcast(Message m) throws InterruptedException, MalformedURLException, RemoteException, NotBoundException{
		if (m == null) {
			return;
		}
		
		
			for(int i = 0; i<num_procs; i++) {
				if(i!= this.id)
				this.send_message(m,i);
			}
		
		return;
	}
	
	//process sends a message to process with id proc_id
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id));
		new Thread(thread).start();

		return;
	}
	
	//print the contents
	private void print_content(){
		System.out.println("Proc " + this.id + " content:");
		if(candidate != null)
			candidate.print_candidate();
		ordinary.print_ordinary();
		return;
	}
	
	//Runnable
	@Override
	public void run() {
		int m;
		Message head;
		boolean termination = false;
		try {
		
			if(true) {
				ordinary= new Ordinary(URLs,this.id);
				candidate= new Candidate(this.id, URLs, true);
				election = true;
				candidate.start();
			}
			
		
			while(!termination) {
				int delay = ThreadLocalRandom.current().nextInt(50, 100);
				Thread.sleep(delay);
				while(!buffer.isEmpty()) {
					head = buffer.get(0);
					
					if(head.type==-1) {
						if(!election) {
							ordinary= new Ordinary(URLs,this.id);
							election = true;
						}
					
					
					if(!elected)ordinary.process(head);
					}
					
					if(head.type==-2){
					
					if(candidate.isCandidate()){
							elected= candidate.process(head);	
							
					}
					
					if(elected) {
						System.out.println(this.id + " has been elected");
						this.print_content();
						this.broadcast(new Message(1,this.id + " has been Elected",0,this.id,this.id));
						termination= true;
						break;
						}
					}
					
					if(head.type == 1) {
						//System.out.println(head.content);
						this.print_content();
						termination = true;
						break;
					}
					
					buffer.remove(0);
				}	
			}
		}
		catch ( InterruptedException | MalformedURLException | RemoteException
				| NotBoundException e) {
			e.printStackTrace();
		}
			
			
			
			
	}
		
		

	
}
