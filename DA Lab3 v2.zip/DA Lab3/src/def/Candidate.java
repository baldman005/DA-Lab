package def;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Candidate {

	private boolean candidate;
	private boolean elected;
	private boolean send;
	private int level, id;
	ArrayList<String> URLs = new ArrayList<String>();
	ArrayList<Integer> untraversed = new ArrayList<Integer>();
	
	public Candidate(int id,  ArrayList<String> URLs, boolean candidate){
		this.level = 0;
		this.URLs = URLs;
		this.id = id;		
		for(int i=0; i< URLs.size(); i++){
			if(i!=id)
				untraversed.add(i);
		}
		this.candidate = candidate;
		send = true;
		elected = false;
	}
	
	public boolean process(Message m) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException {
		if(send && !untraversed.isEmpty()) {
			this.send_message(new Message(-1,null,level,id),untraversed.get(0));
		}
		
		if(m==null)
			return false;
		
		if(m.id == id) {
			level ++;
			send=true;
			if(untraversed.isEmpty())
				return elected = true;
			else
				untraversed.remove(0);
		}
		
		else if(compareMessage(m)) {
			this.send_message(new Message(-1,null,m.level,m.id) ,m.id);
			candidate=false;
		}
		
		else
			send = false;
		
		return false;
	}
	
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id));
		new Thread(thread).start();
		return;
	}
	
	public boolean compareMessage(Message m) {
		
		if(m.level > level) 
			return true;
		
		if(m.level == level && m.id > id)
			return true;
		
		return false;
	}
	
	public boolean isCandidate() {
		return candidate;
	}
	
	
}
