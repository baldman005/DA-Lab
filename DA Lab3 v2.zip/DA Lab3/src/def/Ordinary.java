package def;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Ordinary {
	
	private boolean ordinary;
	private int owner_level, owner_id, father, potential_father;
	ArrayList<String> URLs = new ArrayList<String>();
	ArrayList<Integer> untraversed = new ArrayList<Integer>();
	
	public Ordinary(ArrayList<String> URLs){
		this.URLs = URLs;
		this.owner_id = -1;
		this.father = -1;
		this.potential_father=-1;
		this.owner_level=-1;
		this.ordinary = true;
	}
	
	public void process(Message m) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException {
		
		if(compareMessage(m)) {
			potential_father=m.id;
			owner_level = m.level;
			owner_id = m.id;
			if(father <0) father = potential_father;
			this.send_message(new Message( -1, null,m.level,m.id),father);
		}
		
		else if(owner_level==m.level && owner_id==m.id) {
			father = potential_father;
			this.send_message(new Message( -1, null,m.level,m.id),father);
		}
		
		
	}
	
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id));
		new Thread(thread).start();
		return;
	}
	
	public boolean isOrdinary() {
		return ordinary;
	}
	
public boolean compareMessage(Message m) {
		
		if(m.level > owner_level) 
			return true;
		
		if(m.level == owner_level && m.id > owner_id)
			return true;
		
		return false;
	}
	
}
