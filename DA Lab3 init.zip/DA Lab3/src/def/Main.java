package def;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;



public class Main {
	private static ArrayList<String> URLs = new ArrayList<String>();
	
	
	public static void main(String args[])   {
		int num_procs = 3;
		/*String rmi_name_0 = "rmi://145.94.187.205:1099/p1";
		String rmi_name_1 = "rmi://145.94.227.158:1100/p2";
		String rmi_name_2 = "rmi://145.94.187.205:1101/p3";
		*/
		String rmi_name_0 = "rmi://localhost:1099/p1";
		String rmi_name_1 = "rmi://localhost:1100/p2";
		String rmi_name_2 = "rmi://localhost:1101/p3";
		
		URLs.add(rmi_name_0);
		URLs.add(rmi_name_1);
		URLs.add(rmi_name_2);
		
		Thread t0;
		Thread t1;
		Thread t2;
		
		try {	
		
		Process p0 = new Process(0, num_procs,URLs);
	    Process p1 = new Process(1, num_procs,URLs);
		Process p2 = new Process(2, num_procs,URLs);
		
		Registry reg0 = java.rmi.registry.LocateRegistry.createRegistry(1099);
		Registry reg1 = java.rmi.registry.LocateRegistry.createRegistry(1100);
		Registry reg2 = java.rmi.registry.LocateRegistry.createRegistry(1101);
		
		reg0.bind(rmi_name_0, p0);
		reg1.bind(rmi_name_1, p1);
		reg2.bind(rmi_name_2, p2);

		java.rmi.Naming.bind(rmi_name_0, p0);
	    java.rmi.Naming.bind(rmi_name_1, p1);
	    java.rmi.Naming.bind(rmi_name_2, p2);
	    
	    t0 = new Thread(p0);
	    t0.start();
	    t1 = new Thread(p1);
	    t1.start();
	    t2 = new Thread(p2);
	    t2.start();
	    
	    while(t0.isAlive() || t1.isAlive() || t2.isAlive()) {
	    	Thread.sleep(500);
	    }
	    
	    Thread.sleep(2000);
	    
		reg0.unbind(rmi_name_0);
		reg1.unbind(rmi_name_1);
		reg2.unbind(rmi_name_2);
		UnicastRemoteObject.unexportObject(reg0,true);
		UnicastRemoteObject.unexportObject(reg1,true);
		UnicastRemoteObject.unexportObject(reg2,true);

		} catch ( RemoteException| MalformedURLException| 
				AlreadyBoundException | NotBoundException  
				| InterruptedException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

}
