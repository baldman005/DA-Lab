package def;
import java.io.Serializable;
import java.util.Comparator;

public class Message implements Serializable{

	public int type, level, id;
	String content;
	
	//construct of a Message
	Message(int type, String content, int level, int id){
		this.type = type;
		this.level = level;
		this.id = id;
		this.content = content;
	}
	
	//construct of a Message(maybe I can say that ts is 0 and pid is 0)
	
	//print the contents of the message
	public void print_message(){
		System.out.println(this.content);
	}
}

// Used to order a list of messages
class SortQueue implements Comparator<Message>
{
    public int compare(Message a, Message b)
    {
        if (a.level == b.level)
        	return a.id - b.id;
        else
        	return a.level - b.level;
    }
}
