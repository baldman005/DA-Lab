package def;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Candidate {

	private boolean inElcetion;
	private int level, id, owner_id, father, potential_father;
	ArrayList<String> URLs = new ArrayList<String>();
	ArrayList<Integer> untraversed = new ArrayList<Integer>();
	
	public Candidate(int id,  ArrayList<String> URLs){
		this.level = 0;
		this.URLs = URLs;
		this.id = id;		
		for(int i=0; i< URLs.size(); i++){
			if(i!=id)
				untraversed.add(i);
		}

		
	}
	
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id));
		new Thread(thread).start();
		return;
	}
	
	
}
