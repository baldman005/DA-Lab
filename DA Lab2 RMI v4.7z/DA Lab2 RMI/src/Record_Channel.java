import java.util.ArrayList;



public class Record_Channel {
	
	public int start;
	public int end;
	public ArrayList<Message> buffer = new ArrayList<Message>();
	public int mark_id;
	public int mark_seq_id;
	public int channel_id;

	
	public Record_Channel (int start, int end, int mark_id, int mark_seq_id, int channel_id){
		this.start=start;
		this.end=end;
		this.mark_id=mark_id;
		this.mark_seq_id=mark_seq_id;
		this.channel_id=channel_id;
	}
	
	public void save_buff(ArrayList<Message> buffer){
		
	}
	
	public void print() {
		System.out.println("Channel from proc " + start + "to proc" + end);
		
		for(Message e:this.buffer){
			e.print_message();
		}
		System.out.println("Mark : " + mark_id);
		System.out.println("Marq_Seq : " + mark_seq_id);
	}
	
	public void print_buffer(){
		if(this.buffer.isEmpty()) {
			System.out.println("empty");
		}
		for(Message e:this.buffer){
			e.print_message();
		}
	}

}
