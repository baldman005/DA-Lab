
import java.io.Serializable;
import java.util.Comparator;

public class Message implements Serializable{
	/*m - the content of the message
	  ts - the timestamp
	  pid - to be found*/
	public int m, id , seq, start;
	
	//construct of a Message
	Message(int m, int id, int seq, int start){
		this.m = m;
		this.id = id;
		this.seq=seq;
		this.start=start;
	}
	
	//print the contents of the message
	public void print_message(){
		System.out.println(this.m + " " + this.id + " " + this.seq + " "+ start);
	}
}

// Used to order a list of messages
class SortQueue implements Comparator<Message>
{
    public int compare(Message a, Message b)
    {
        if (a.seq == b.seq)
        	return a.id - b.id;
        else
        	return a.seq - b.seq;
    }
}
