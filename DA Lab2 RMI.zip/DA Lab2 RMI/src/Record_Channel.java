import java.util.ArrayList;



public class Record_Channel {
	
	public int start;
	public int end;
	public ArrayList<Message> buffer = new ArrayList<Message>();
	public int mark_id;
	public int mark_seq_id;
	
	public Record_Channel (int start, int end, int state, int mark_id, int mark_seq_id){
		this.start=start;
		this.end=end;
		this.mark_id=mark_id;
		this.mark_seq_id=mark_seq_id;
	}
	
	public void print() {
		System.out.println("Channel from proc " + start + "to proc" + end);
		
		for(Message e:this.buffer){
			e.print_message();
		}
		System.out.println("Mark : " + mark_id);
		System.out.println("Marq_Seq : " + mark_seq_id);
	}

}
