
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Process extends UnicastRemoteObject implements Reception, Runnable {
	//PrintWriter writer;
	private int ts = 0;
	private int id;
	private static int num_procs;
	private ArrayList<Message> buffer = new ArrayList<Message>();
	private ArrayList<ArrayList<Message>> channel_buffer = new ArrayList<ArrayList<Message>>();
	private static ArrayList<String> URLs = new ArrayList<String>();
	private boolean all_acks;
	private int state = 0;
	private ArrayList<Integer> state_value = new ArrayList<Integer>();
	private ArrayList<Record_State> records_state = new ArrayList<Record_State>();
	private ArrayList<Record_Channel> records_channels = new ArrayList<Record_Channel>();

	//constructor
	protected Process(int id, int num_procs, ArrayList<String> URLs/*, String file*/) throws RemoteException {
		super(1099); //AQUI 1099?
		this.id=id;
		for(int i=0; i < num_procs; i++)
			state_value.add(0);
		Process.num_procs=num_procs;
		Process.URLs=URLs;
		//this.writer = new PrintWriter("the-file-name.txt", "UTF-8");
	}
	
	//prints the buffer
	public void print_buffer(){
		System.out.println("Buffer " + this.id );
		for(Message e:this.buffer){
			e.print_message();
		}
	}
	
	//prints the deliveries
	
	//prints the acks
	
	//prints all the lists and timestamp
	public void print_content(){
		System.out.println("Process:" + this.id + " ts:" + this.ts);
		this.print_buffer();
	}
	
	//delivers a message in buffer and verifies if next one is ready
	//receive message
	@Override
	public  void receive_message(Message m) throws RemoteException, InterruptedException, MalformedURLException, NotBoundException {
		synchronized (this){
		buffer.add(m);
		//System.out.println(this.id + " rec ");
		Collections.sort(this.buffer, new SortQueue());
		}
		//ADICIONEI AQUI

				
		return;
	}

	//receive ack

	
	
	//broadcast message or ack
	public void broadcast(Message m) throws InterruptedException, MalformedURLException, RemoteException, NotBoundException{
		if (m == null) {
			return;
		}
		
		int i;

		
	
			for(i = 0; i<num_procs; i++) {
				this.send_message(m,i);
			}
		
		
		return;
	}
	
	//process sends a message to process with id proc_id
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id),proc_id);
		new Thread(thread).start();

		return;
	}
	
	//process sends an ack to process with id proc_id
	
	//manages a received ack

	//Runnable
	@Override
	public void run() {
		int m;
		Message head;
		Ack a;
		boolean termination = false;
		
		
		if(this.id == 0) {
			try {
				while(!termination) {
					//Read receive buffer update accordingly
					Thread.sleep(100);
					switch(state){
						case(-1):
								//send_mark
								//state=prev_state
								break;
						case(0): //send_message()
								state++;
						case(1)://send_message()
								 state++;
							
						default:		
								termination = true;
							  break;
					}
				}
			} catch ( InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		if(this.id == 1) {
			try {
				while(!termination) {
					Thread.sleep(100);
					
					switch(state){
						case(0): 
							termination = true;
							break;
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		if(this.id == 2) {
			try {
				while(!termination) {
					Thread.sleep(100);
					switch(state){
						case(0): 
								termination = true;
							    break;
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}
}
