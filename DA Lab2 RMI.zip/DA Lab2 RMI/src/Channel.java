import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayList;

public class Channel implements Runnable {
	
	private String URL;
	private ArrayList<Message> fifo = new ArrayList<Message>();
 	private int proc;
	
	
	public Channel(String URL, int proc) {
		this.URL=URL;
		this.proc = proc;
		return;
	}
	
	@Override
	public void run () {		
		Reception receiver;
		try {
			if(fifo.isEmpty())
				Thread.sleep(100);
			else {
			int delay = 1000*proc + 5000;
			Thread.sleep(delay);
			receiver = (Reception) java.rmi.Naming.lookup(URL);
			receiver.receive_message(fifo.get(0));
			fifo.remove(0);
			}
		} catch (MalformedURLException | RemoteException | NotBoundException | InterruptedException e) {
			e.printStackTrace();
		}

		return;
	}

}
