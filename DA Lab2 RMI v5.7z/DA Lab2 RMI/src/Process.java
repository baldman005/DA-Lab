/*
 * MAJOR ERROS Q ENCONTREI:
 * 2� parametro do Message dava erro neste exemplo com 3 processes. Foi preciso criar o get_channel_m
 * alguns if(...); (ou seja com um ponto e virgula a mais)
 * save simplesmente nao estava a dar e mudei para ser mais simples,
  quando recebe um marker decrementa e quando envia incrementa, ou seja,
  no final vai tar com save a 0 obrigatoriamente (e aparentemente funciona assim)
 *Aparentemente funciona pelo menos com este exemplo (yay)
 *Amanha experimentar com mais um marker
 */

import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Process extends UnicastRemoteObject implements Reception, Runnable {
	//PrintWriter writer;
	private int id;
	private static int num_procs;
	private ArrayList<Message> buffer = new ArrayList<Message>();
	public ArrayList<Channel_buffer> channel_buffers = new ArrayList<Channel_buffer>();
	private int n_read=0;
	private int state = 0;
	public ArrayList<Integer> state_value = new ArrayList<Integer>();
	private ArrayList<Record_State> records_state = new ArrayList<Record_State>();
	private ArrayList<Record_Channel> records_channels = new ArrayList<Record_Channel>();
	private ArrayList<Channel> channels = new ArrayList<Channel>();
	private ArrayList<Marker> markers = new ArrayList<Marker>();
	public int save = 0;

	//constructor
	protected Process(int id, int num_procs, ArrayList<String> URLs/*, String file*/) throws RemoteException {
		super(1099); //AQUI 1099?
		this.id=id;
		for(int i=0; i < 2*(num_procs-1); i++)
			state_value.add(0);
		for(int j = 0, i = 0; j< num_procs ; j ++ ){
			if(j != id){
				channels.add(new Channel(URLs.get(j),i, this.id*(num_procs-1)+i));
				Thread thread = new Thread(channels.get(i));
				thread.start();
				i++;
			}
			
		}
		Process.num_procs=num_procs;
		//this.writer = new PrintWriter("the-file-name.txt", "UTF-8");
	}
	
	//prints the buffer
	public void print_buffer(){
		System.out.println("Buffer " + this.id );
		for(Message e:this.buffer){
			e.print_message();
		}
	}
	
	public ArrayList<Message> channel_to_proc (ArrayList<Message> buffer){
		for (int j = 0;j< buffer.size(); j++ ){
			buffer.get(j).id=convert(buffer.get(j).id);
		}
		return buffer;
	}
	
	private int convert(int channel_id){
		if(channel_id < this.id){
			return channel_id;
		}
		else{
			return ++channel_id;
		}
	}
	
	private int get_channel_m(int channel_sender, int sender){
		int receiver;
		
		if(channel_sender >= sender)
			receiver = channel_sender + 1;
		else
			receiver = channel_sender;
		
		if(receiver < sender)
			return (sender-1);
		else
			return (sender);
	}
	
	//prints all the lists and timestamp
	public void print_content(){
		System.out.println("Process:" + this.id );
		this.print_buffer();
	}
	
	//delivers a message in buffer and verifies if next one is ready
	//receive message
	@Override
	public  void receive_message(Message m) throws RemoteException, InterruptedException, MalformedURLException, NotBoundException {
		synchronized (this){
		buffer.add(m);
		//Collections.sort(this.buffer, new SortQueue());
		}

		return;
	}
	
	//broadcast message
	public void broadcast(Message m) throws InterruptedException, MalformedURLException, RemoteException, NotBoundException{
		if (m == null) {
			return;
		}
		int i;
		for(i = 0; i<num_procs-1; i++) {
			this.send_message(m,channels.get(i));
			this.save++;
		}
		
		return;
	}
	
	//process sends a message to process with id proc_id
	public void send_message(Message m, Channel channel) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		//Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id),proc_id);
		//new Thread(thread).start();
		channel.add_to_fifo(m);
		return;
	}
	
	public void record_state(Message m){
		Record_State record = new Record_State(this.id,this.state_value,m.id,m.seq);
		records_state.add(record);
		return;
	}
	
	public void print_records() {
		
		int sender = 0;
		if(this.records_state.isEmpty())
			System.out.println("There were no recordings");
		
		for(int i = 0; i < this.records_state.size() ; i++ ) {
	    System.out.println("Global recording started by proc "  + this.records_state.get(i).mark_id  + " with seq " + this.records_state.get(i).mark_seq_id );
		System.out.println("Proc " + this.id + " State is : " + this.records_state.get(i).state);
		
			for(int j = 0; j < (num_procs - 1);j++) {
				
				if(j<this.id)
					sender=j;
				else
					sender = j+1;
				
				
				for( int k = 0; k < this.records_channels.size(); k++) {
					if( sender == this.records_channels.get(k).start && 
							this.records_channels.get(k).mark_id == this.records_state.get(i).mark_id  && 
							this.records_channels.get(k).mark_seq_id==this.records_state.get(i).mark_seq_id) {
						System.out.println("Channel from " + this.records_channels.get(k).start + " to " + this.records_channels.get(k).end);
						this.records_channels.get(k).buffer=this.channel_to_proc(this.records_channels.get(k).buffer);
						this.records_channels.get(k).print_buffer();
					}
				}
			}
		}
	}
	
	public int mark_reception(int proc_id, int seq, int state, int sender) {
		Marker mark = new Marker(proc_id,seq,1);
		boolean not_included = true;
		
		//Checking if already received marker to count number of markers received
		
		for(Marker m:this.markers){
			if(m.proc_id == proc_id && m.seq == seq){
				m.counter++;
				for(Record_Channel r:this.records_channels)
					if(r.start == sender && r.mark_id == proc_id && r.mark_seq_id == seq)
						for(Channel_buffer c:channel_buffers)
							if (c.mark_id == proc_id && c.seq == seq 
								&& c.channel_id == r.channel_id)
								r.buffer = c.buffer;
				not_included=false;
			}
		}
		
		if(not_included) {
			//System.out.println("It's high noon");
			mark.counter=1;
			this.markers.add(mark);
			this.records_state.add(new Record_State(this.id, state_value, proc_id, seq));
			
			for(int i = 0; i < num_procs-1; i++) {
				//channel_buffers.add(new Channel_buffer(i,mark.proc_id,mark.seq));
				
				if(i < this.id){
					 records_channels.add(new Record_Channel(i, this.id, mark.proc_id,mark.seq,i));
				}
				else{
					 records_channels.add(new Record_Channel(i+1, this.id,mark.proc_id, mark.seq,i));
				}
			}
	
			return 1;
		}
		
		return 0;
	}
	
	public void send_marker(Marker mark) {
		boolean not_included= true;
		
		//System.out.println("What do you mean sauce?");
				
		for(int i = 0; i < this.markers.size(); i++ ) {
			if(this.markers.get(i).proc_id == mark.proc_id && this.markers.get(i).seq == mark.seq) {
				not_included=false;
			}
		}
	
		if(not_included) {
			mark.counter=0;
			this.markers.add(mark);
			this.records_state.add(new Record_State(this.id, state_value, mark.proc_id, mark.seq));
			for(int i = 0; i < num_procs-1; i++) {
				//channel_buffers.add(new Channel_buffer(i,mark.proc_id,mark.seq));
				
				if(i < this.id){
					 records_channels.add(new Record_Channel(i, this.id, mark.proc_id,mark.seq,i));
				}
				else{
					 records_channels.add(new Record_Channel(i+1, this.id,mark.proc_id, mark.seq,i));
				}	
			}
		}
		
		for(int i = 0; i<num_procs-1; i++) {
			channel_buffers.add(new Channel_buffer(i,mark.proc_id,mark.seq));
		}
		
		try {
			broadcast(new Message(-1,mark.proc_id,mark.seq,this.id));
		} catch (MalformedURLException | RemoteException | InterruptedException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	private boolean check_end(int num_marks){
		if(this.markers.size() != num_marks){
			return false;
		}
		if(this.save != 0){
			//System.out.println(this.save);
			return false;
		}
		return true;
	}
	
	//Runnable
	@Override
	public void run() {

		Message m;
		Marker mark = new Marker(this.id,1,0); 
		int delay=0;
		boolean termination = false;
		int num_marks = 1;
		
		
		if(this.id == 0) {
			try {
				while(!termination) {
					//Read receive buffer update accordingly
					delay=ThreadLocalRandom.current().nextInt(50, 500);
					Thread.sleep(100);
					
					for(; n_read<(buffer.size()); n_read++){
						m= buffer.get(n_read);
						if(m.m < 0) {
							if(mark_reception(m.id,m.seq,state,m.start) == 1)
								send_marker(new Marker(m.id,m.seq,1));
							this.save--;
						}
						else {
							
							if( save > 0) {

								for(int i =0; i< channel_buffers.size(); i++) {
									if(channel_buffers.get(i).channel_id==get_channel_m(m.id,m.start))
										channel_buffers.get(i).buffer.add(m);
									}
							}
							state_value.set((num_procs-1)+get_channel_m(m.id,m.start),m.m);	
						}
					}
					switch(state){
						case(-1):
								send_marker(new Marker(mark.proc_id,mark.seq,0));
								mark.seq++;
								state = 1;
								break;
						case(0): 
							   m = new Message(5,(channels.get(0)).id,state,this.id);
							   send_message(m,channels.get(0));
							   state_value.set(m.id,m.m);
							   state=-1;
						       break;
						case(1):m = new Message(8,(channels.get(0)).id,state,this.id);
						   		send_message(m,channels.get(0));
						   		state_value.set(m.id,m.m);
								 state++;
						case(2): m = new Message(9,(channels.get(1)).id,state,this.id);
							   send_message(m,channels.get(1));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						default:
							if(check_end(num_marks))
								termination = true;
							  break;
					}
				}
				//this.buffer=this.channel_to_proc(this.buffer);
				this.print_records();
				//System.out.println(state_value);
				
			} catch ( InterruptedException | MalformedURLException | RemoteException
					| NotBoundException e) {
				e.printStackTrace();
			}
		}
		
		if(this.id == 1) {
			try {
				while(!termination) {
					//Read receive buffer update accordingly
					delay=ThreadLocalRandom.current().nextInt(50, 500);
					Thread.sleep(100);
					
					for(; n_read<(buffer.size()); n_read++){
						m= buffer.get(n_read);
						if(m.m < 0) {
							if(mark_reception(m.id,m.seq,state,m.start) == 1)
								send_marker(new Marker(m.id,m.seq,1));
							this.save--;
						}
						else {
							
							if( save > 0) {

								for(int i =0; i< channel_buffers.size(); i++) {
									if(channel_buffers.get(i).channel_id==get_channel_m(m.id,m.start))
										channel_buffers.get(i).buffer.add(m);
									}
							}
							state_value.set((num_procs-1)+get_channel_m(m.id,m.start),m.m);	
						}
					}
					switch(state){
						case(-1):
						
								send_marker(new Marker(mark.proc_id,mark.seq,0));
								mark.seq++;
								state = 2;
								break;
						case(0): 
							   m = new Message(1,(channels.get(0)).id,state,this.id);
							   send_message(m,channels.get(0));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						case(1):	
								m = new Message(2,(channels.get(1)).id,state,this.id);
						   		send_message(m,channels.get(1));
						   		state_value.set(m.id,m.m);
								state++;
								break;
						case(2): m = new Message(3,(channels.get(0)).id,state,this.id);
							   send_message(m,channels.get(0));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						default:
							
							if(check_end(num_marks))
								termination = true;
							  break;
					}
				}
				//this.buffer=this.channel_to_proc(this.buffer);
				this.print_records();
				//System.out.println(state_value);
				
			} catch ( InterruptedException | MalformedURLException | RemoteException
					| NotBoundException e) {
				e.printStackTrace();
			}
		}
		
		if(this.id == 2) {
			try {
				while(!termination) {
					//Read receive buffer update accordingly
					delay=ThreadLocalRandom.current().nextInt(50, 500);
					Thread.sleep(100);
					
					for(; n_read<(buffer.size()); n_read++){
						m= buffer.get(n_read);
						if(m.m < 0) {
							if(mark_reception(m.id,m.seq,state,m.start) == 1)
								send_marker(new Marker(m.id,m.seq,1));
							this.save--;
						}
						else {
							if( save > 0) {

								for(int i =0; i< channel_buffers.size(); i++) {
									if(channel_buffers.get(i).channel_id==get_channel_m(m.id,m.start))
										channel_buffers.get(i).buffer.add(m);
									}
							}
							state_value.set((num_procs-1)+get_channel_m(m.id,m.start),m.m);	
						}
					}
					switch(state){
						case(-1):
								send_marker(new Marker(mark.proc_id,mark.seq,0));
								mark.seq++;
								state = 1;
								break;
						case(0): 
							   m = new Message(20,(channels.get(0)).id,state,this.id);
							   send_message(m,channels.get(0));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						case(1):m = new Message(21,(channels.get(1)).id,state,this.id);
				   					send_message(m,channels.get(1));
				   					state_value.set(m.id,m.m);
				   					state++;
						case(2): m = new Message(22,(channels.get(1)).id,state,this.id);
							   send_message(m,channels.get(1));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						default:
							if(check_end(num_marks))
								termination = true;
							  break;
					}
				}
				//this.buffer=this.channel_to_proc(this.buffer);
				this.print_records();
				//System.out.println(state_value);
				
			} catch ( InterruptedException | MalformedURLException | RemoteException
					| NotBoundException e) {
				e.printStackTrace();
			}
		}
	}
}
