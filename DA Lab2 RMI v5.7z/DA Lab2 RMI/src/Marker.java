import java.util.ArrayList;

public class Marker {
		public int proc_id, seq, counter;
		
		public Marker(int id, int seq, int count){
			this.proc_id=id;
			this.seq=seq;
			counter=count;
		}
		
		public void print_marker(){
			System.out.println(proc_id+" "+seq+" "+counter);
		}
}
