package def;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.concurrent.ThreadLocalRandom;

public class Delay_Message_Thread implements Runnable {

	private String URL;
	private Message m;
//	private int i;
	
	
	public Delay_Message_Thread(Message m, String URL) {
		this.URL=URL;
		this.m=m;
		return;
	}
	
	@Override
	public void run () {		
		Reception receiver;
		try {
			int delay = ThreadLocalRandom.current().nextInt(50, 500);
			Thread.sleep(delay);
			receiver = (Reception) java.rmi.Naming.lookup(URL);
			receiver.receive_message(m);
		} catch (MalformedURLException | RemoteException | NotBoundException | InterruptedException e) {
			e.printStackTrace();
		}

		return;
	}

}
