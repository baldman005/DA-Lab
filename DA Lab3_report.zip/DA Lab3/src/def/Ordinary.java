package def;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Ordinary {
	
	private boolean ordinary;
	public int owner_level, owner_id, father, potential_father, proc_id, kills = 0;
	public int acks_sent = 0;
	ArrayList<String> URLs = new ArrayList<String>();
	ArrayList<Integer> untraversed = new ArrayList<Integer>();
	ArrayList<Integer> potential_list = new ArrayList<Integer>();
	ArrayList<Integer> confirmed_list = new ArrayList<Integer>();
	private ArrayList<Channel> channels = new ArrayList<Channel>();
	public int n_rec;
	public int cap_rec;
	public int kill_confirm=0;
	private boolean fifo;

	
	public Ordinary(ArrayList<String> URLs, int proc_id,ArrayList<Channel> channels){
		this.URLs = URLs;
		this.owner_id = -1;
		this.father = -1;
		this.potential_father=-1;
		this.owner_level=-1;
		this.ordinary = true;
		this.proc_id = proc_id;
		this.channels=channels;
		this.fifo=true;
		this.cap_rec=0;
		n_rec=0;
	}
	
	public void process(Message m) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException {
		
		if(m.content!=null) {
		if(m.content.equals(new String("cap")))
			cap_rec++;
		if(m.content.equals("killed"))
			kill_confirm++;
		}
		n_rec++;
		if(compareMessage(m)) {
			potential_father=m.id;
			potential_list.add(m.id);
			owner_level = m.level;
			owner_id = m.id;
			if(father <0) {
				acks_sent++;
				father = potential_father;
				confirmed_list.add(father);
				this.send_message(new Message( -2, "ack",m.level,m.id, this.proc_id),father);
			}
			else {
				kills++;
				this.send_message(new Message( -2, "kill",m.level,m.id, this.proc_id),father);
			}
			
		}
		
		else if(owner_level==m.level && owner_id==m.id) {
			father = potential_father;
			confirmed_list.add(father);
			acks_sent++;
			this.send_message(new Message( -2, "ack",m.level,m.id,this.proc_id),father);
			
		}
		
	}
	
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		if(fifo)
			channels.get(proc_id).add_to_fifo(m);
		else{
			Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id));
			new Thread(thread).start();
		}

	}
	
	public boolean isOrdinary() {
		return ordinary;
	}
	
	public boolean compareMessage(Message m) {
		
		if(m.level > owner_level) 
			return true;
		
		if(m.level == owner_level && m.id > owner_id)
			return true;
		
		return false;
	}
	
	public void print_ordinary(){
		System.out.println(" Ordinary owner_level:" + owner_level);
		System.out.println(" Owner_id:" + owner_id);
		System.out.println(" Father:" + father);
		System.out.println(" Fathers killed:" + kills);
		System.out.println(" Acks_sent:" + acks_sent);
		return;
	}
}
