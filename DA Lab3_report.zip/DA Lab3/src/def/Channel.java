package def;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayList;

	public class Channel implements Runnable {
		
		private String URL;
		private ArrayList<Message> fifo = new ArrayList<Message>();
	 	public int id;
	 	public int unique_id;
	 	private boolean shutdown = false;
	 
		
		
		public Channel(String URL, int id, int unique_id) {
			this.URL=URL;
			this.id = id;
			this.unique_id=unique_id;
			return;
		}
		@Override
		public void run () {		
			Reception receiver;
			try {
				while(!shutdown){
				if(fifo.isEmpty()) {
					Thread.sleep(100);
				}
				else {
				int delay;	
				//int delay = ThreadLocalRandom.current().nextInt(50, 2000);
				if(unique_id>=6)
					delay=1000;
				else
					delay=500;
				//System.out.println(fifo.get(0).content);
				Thread.sleep(delay);
				receiver = (Reception) java.rmi.Naming.lookup(URL);
				
				synchronized(fifo) {
					receiver.receive_message(fifo.get(0));
					fifo.remove(0);
						}
					}
				}
			} catch (MalformedURLException | RemoteException | NotBoundException | InterruptedException e) {
				e.printStackTrace();
			}
		
			

			return;
		}
		
		public void add_to_fifo(Message m){
			synchronized(fifo){			
				fifo.add(m);
				}
			return;
		}
		
		public void shutdown(){
			this.shutdown = true;
		}
			

	}

