package def;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Main {
	private static boolean ThreadAlive(ArrayList<Thread> t){
		for(int i=0; i<t.size(); i++)
			if(t.get(i).isAlive())
				return true;
		
		return false;
	}
	
	public static void report(ArrayList<Candidate> candidates, ArrayList<Ordinary> ordinaries){
		System.out.println("Winner is " + ordinaries.get(0).father);
		System.out.println("Candidates: ");
		for(Candidate e:candidates){
			System.out.println(" id: " + e.id);
			System.out.println(" level: " + e.level);
			System.out.println(" kills: " + e.kills);
			if(!e.cand_killers.isEmpty())
				System.out.println(" Cand_killers: ");
			else
				System.out.println(" Cand_killers is empty ");
			for(Integer c:e.cand_killers){
				System.out.println("   " + c.intValue());
			}
			
			if(!e.ord_killers.isEmpty())
				System.out.println(" Ord_killer: ");
			else
				System.out.println(" Ord_killer is empty ");
			for(Integer c:e.ord_killers){
				System.out.println("   " + c.intValue());
			}
			
			if(!e.nodes_captured.isEmpty())
				System.out.println(" Nodes_captured: ");
			else
				System.out.println(" Nodes_captured is empty ");
			for(Integer c:e.nodes_captured){
				System.out.println("   " + c.intValue());
			}
			System.out.println("---------");
		}
		System.out.println("Ordinaries: ");
		for(Ordinary e:ordinaries){
			System.out.println(" id: " + e.proc_id);
			if(!e.potential_list.isEmpty())
				System.out.println(" Potential_list: ");
			else
				System.out.println(" Potential_list is empty ");
			for(Integer c:e.potential_list){
				System.out.println("   " + c.intValue());
			}
			
			if(!e.confirmed_list.isEmpty())
				System.out.println(" Confirmed_list: ");
			else
				System.out.println(" Confirmed_list is empty ");
			for(Integer c:e.confirmed_list){
				System.out.println("   " + c.intValue());
			}
			System.out.println("---------");
		}	
	}
	
	private static ArrayList<String> URLs = new ArrayList<String>();
	
	public static void main(String args[])   {
		ArrayList<Candidate> candidates = new ArrayList<Candidate>();
		ArrayList<Ordinary> ordinaries = new ArrayList<Ordinary>();
		int num_procs = 4;
		int num_procs_mine = 4;
		
		for(int i=0; i<num_procs; i++){
			//if(i>=num_procs_mine)
			if(i<num_procs_mine)
				URLs.add("rmi://localhost:" + (1099+i) + "/p" + i);
			else
				//COLOCAR IP
				URLs.add("rmi://:" + (1099+i) + "/p" + i);
		}
			
		ArrayList<Thread> t = new ArrayList<Thread>();
		
		try {
			
		ArrayList<Process> p = new ArrayList<Process>();
		for(int i=0; i<num_procs_mine; i++)
			p.add(new Process(i,num_procs,URLs));
		
		ArrayList<Registry> reg = new ArrayList<Registry>();
		//for(int i=num_procs_mine; i<num_procs; i++){
		for(int i=0; i<num_procs_mine; i++)
			reg.add( java.rmi.registry.LocateRegistry.createRegistry(1099+i));
		
		//for(int i=num_procs_mine; i<num_procs; i++){
		for(int i=0; i<num_procs_mine; i++)
			reg.get(i).bind(URLs.get(i), p.get(i));
		
		//for(int i=num_procs_mine; i<num_procs; i++){
		for(int i=0; i<num_procs_mine; i++)
			java.rmi.Naming.bind(URLs.get(i), p.get(i/*-num_proc_mine*/));
	    
		//for(int i=num_procs_mine; i<num_procs; i++){
		for(int i=0; i<num_procs_mine; i++){
			t.add(new Thread(p.get(i)));
			t.get(i).start();
		}
		
	    
	    while(ThreadAlive(t)) {
	    	Thread.sleep(500);
	    }
	    
	    for(Process e:p){
	    	candidates.add(e.returnCandidate());
	    	ordinaries.add(e.returnOrdinary());
	    }
	    Thread.sleep(2000);
	    report(candidates,ordinaries);
	    
	    for(int i=0; i<num_procs; i++)
	    	reg.get(i).unbind(URLs.get(i));
	    
	    for(int i=0; i<num_procs; i++)
			UnicastRemoteObject.unexportObject(reg.get(i),true);

		} catch ( RemoteException| MalformedURLException| 
				AlreadyBoundException | NotBoundException  
				| InterruptedException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
}
