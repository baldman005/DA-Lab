package def;

import java.net.MalformedURLException;
import java.util.Random;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Candidate {
	private Random rand = new Random();
	private int last_link = -1;
	private int link = -1;
	private boolean candidate, killed;
	private boolean elected;
	private boolean send;
	public int level, id, kills = 0;
	ArrayList<String> URLs = new ArrayList<String>();
	ArrayList<Integer> untraversed = new ArrayList<Integer>();
	ArrayList<Integer> cand_killers = new ArrayList<Integer>(); 
	ArrayList<Integer> ord_killers = new ArrayList<Integer>(); 
	ArrayList<Integer> nodes_captured = new ArrayList<Integer>(); 

	public Candidate(int id,  ArrayList<String> URLs, boolean candidate){
		this.level = 0;
		this.URLs = URLs;
		this.id = id;		
		for(int i=0; i< URLs.size(); i++){
			untraversed.add(i);
		}
		this.candidate = candidate;
		send = true;
		elected = false;
		killed = false;
	}
	
	public void start() throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		link = rand.nextInt((untraversed.size()));
		//link = ThreadLocalRandom.current().nextInt(0, untraversed.size());
		//System.out.println(untraversed.get(link) +  "|" + this.id);
		this.send_message(new Message(-1,null,level,id,this.id),untraversed.get(link));
		untraversed.remove(link);
	
	}
	
	public boolean process(Message m) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException {
		if(m==null)
			return false;
		
		if(m.id == id && killed == false) {
			level ++;
			nodes_captured.add(m.sender);
		
			if(untraversed.isEmpty())
				return elected = true;
			else{
				link = rand.nextInt((untraversed.size()));
				//link = ThreadLocalRandom.current().nextInt(0, untraversed.size());
				//System.out.println(untraversed.get(link) +  "|" + this.id);
				this.send_message(new Message(-1,null,level,id,this.id),untraversed.get(link));
				untraversed.remove(link);
			}
		}
		
		else if(compareMessage(m)) {
			//System.out.println(this.id + " has been killed");
			this.send_message(new Message(-1,null,m.level,m.id,this.id) ,m.sender);
			killed = true;
			kills++;
			cand_killers.add(m.id);
			ord_killers.add(m.sender);
		}
		
		return false;
	}
	
	public void send_message(Message m, int proc_id) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id));
		new Thread(thread).start();
		return;
	}
	
	public boolean compareMessage(Message m) {
		
		if(m.level > level) 
			return true;
		
		if(m.level == level && m.id > id)
			return true;
		
		return false;
	}
	
	public boolean isCandidate() {
		return candidate;
	}
	
	public void print_candidate(){
		System.out.println(" Candidate level:" + level);
		return;
	}
	
}
