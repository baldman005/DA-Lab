
import java.util.ArrayList;

public class Marker {
		public int id, seq, counter;
		public Marker(int id, int seq){
			this.id=id;
			this.seq=seq;
			counter=1;
		}
}
