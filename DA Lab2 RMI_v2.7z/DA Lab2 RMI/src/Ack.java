
import java.io.Serializable;

public class Ack implements Serializable {

		/*
		 * ts - timestamp
		 * id - id of the sender
		 */
		int ts;
		int id;
		int counter;
		
		Ack(int ts, int id){
			this.ts = ts;
			this.id = id;
			this.counter = 1;
		}
		
		//print the contents of the message
		public void print_ack(){
			System.out.println(this.ts + " " + this.id + " " + this.counter);
		}
	}

