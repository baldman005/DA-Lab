import java.util.ArrayList;

public class Record_State {
	
	public int proc_id;
	public ArrayList<Integer> state = new ArrayList<Integer>();
	public int mark_id;
	public int mark_seq_id;
	public boolean record = false;
	
	public Record_State (int proc_id, ArrayList<Integer> state, int mark_id, int mark_seq_id){
		this.proc_id=proc_id;
		this.state=state;
		this.mark_id=mark_id;
		this.mark_seq_id=mark_seq_id;
		this.record=true;
	}
	
	public void print() {
		System.out.println("Process : " + proc_id);
		System.out.println("State : " + state);
		System.out.println("Mark : " + mark_id);
		System.out.println("Marq_Seq : " + mark_seq_id);
	}
	
}
