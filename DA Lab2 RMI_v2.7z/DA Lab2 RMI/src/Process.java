
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Process extends UnicastRemoteObject implements Reception, Runnable {
	//PrintWriter writer;
	private int ts = 0;
	private int id;
	private static int num_procs;
	private ArrayList<Message> buffer = new ArrayList<Message>();
	private ArrayList<ArrayList<Message>> channel_buffer = new ArrayList<ArrayList<Message>>();
	private static ArrayList<String> URLs = new ArrayList<String>();
	private int n_read=0;
	private int state = 0;
	private ArrayList<Integer> state_value = new ArrayList<Integer>();
	private ArrayList<Record_State> records_state = new ArrayList<Record_State>();
	private ArrayList<Record_Channel> records_channels = new ArrayList<Record_Channel>();
	private ArrayList<Channel> channels = new ArrayList<Channel>();
	private ArrayList<Marker> markers = new ArrayList<Marker>();
	private boolean save = false;

	//constructor
	protected Process(int id, int num_procs, ArrayList<String> URLs/*, String file*/) throws RemoteException {
		super(1099); //AQUI 1099?
		this.id=id;
		for(int i=0; i < num_procs; i++)
			state_value.add(0);
		for(int j = 0, i = 0; j< num_procs ; j ++ ){
			if(j != id){
				channels.add(new Channel(URLs.get(j),i));
				Thread thread = new Thread(channels.get(i));
				thread.start();
				i++;
			}
		}
			
		Process.num_procs=num_procs;
		Process.URLs=URLs;
		//this.writer = new PrintWriter("the-file-name.txt", "UTF-8");
	}
	
	//prints the buffer
	public void print_buffer(){
		System.out.println("Buffer " + this.id );
		for(Message e:this.buffer){
			e.print_message();
		}
	}
	
	public ArrayList<Message> channel_to_proc (ArrayList<Message> buffer){
		for (int j = 0;j< buffer.size(); j++ ){
			buffer.get(j).id=convert(buffer.get(j).id);
		}
		return buffer;
	}
	
	private int convert(int channel_id){
		if(channel_id < this.id){
			return channel_id;
		}
		else{
			return ++channel_id;
		}
	}
	
	//prints the deliveries
	
	//prints the acks
	
	//prints all the lists and timestamp
	public void print_content(){
		System.out.println("Process:" + this.id + " ts:" + this.ts);
		this.print_buffer();
	}
	
	//delivers a message in buffer and verifies if next one is ready
	//receive message
	@Override
	public  void receive_message(Message m) throws RemoteException, InterruptedException, MalformedURLException, NotBoundException {
		synchronized (this){
		buffer.add(m);
		Collections.sort(this.buffer, new SortQueue());
		}
		//ADICIONEI AQUI

				
		return;
	}

	//receive ack

	
	
	//broadcast message or ack
	public void broadcast(Message m) throws InterruptedException, MalformedURLException, RemoteException, NotBoundException{
		if (m == null) {
			return;
		}
		
		int i;

		
	
			for(i = 0; i<num_procs; i++) {
				//this.send_message(m,i);
			}
		
		
		return;
	}
	
	//process sends a message to process with id proc_id
	public void send_message(Message m, Channel channel) throws MalformedURLException, RemoteException, NotBoundException, InterruptedException{
		//Delay_Message_Thread thread = new Delay_Message_Thread( m, URLs.get(proc_id),proc_id);
		//new Thread(thread).start();
		channel.add_to_fifo(m);
		return;
	}
	
	public void record_state(Message m){
		Record_State record = new Record_State(this.id,this.state_value,m.id,m.seq);
		records_state.add(record);
		return;
	}
	
	//Runnable
	@Override
	public void run() {

		Message m;
		Ack a;
		boolean termination = false;
		
		
		if(this.id == 0) {
			try {
				while(!termination) {
					//Read receive buffer update accordingly
					Thread.sleep(100);
					
					for(; n_read<(buffer.size()); n_read++){
						m= buffer.get(n_read);
						state_value.set((num_procs-1)+m.id,m.m);
					}
					switch(state){
						case(-1):
								//send_mark
								//state=prev_state
								break;
						case(0): 
							   m = new Message(5,(channels.get(0)).id,state);
							   send_message(m,channels.get(0));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						case(1):m = new Message(8,(channels.get(0)).id,state);
						   		send_message(m,channels.get(0));
						   		state_value.set(m.id,m.m);
								 state++;
							
						default:
								if(buffer.size()==2)
								  termination = true;
							  break;
					}
					
					
				}
				this.buffer=this.channel_to_proc(this.buffer);
				this.print_buffer();
				System.out.println(state_value);
				
			} catch ( InterruptedException | MalformedURLException | RemoteException
					| NotBoundException e) {
				e.printStackTrace();
			}
		}
		
		if(this.id == 1) {
			try {
				while(!termination) {
					//Read receive buffer update accordingly
					Thread.sleep(100);
					
					for(; n_read<(buffer.size()); n_read++){
						m= buffer.get(n_read);
						state_value.set((num_procs-1)+m.id,m.m);
					}
					switch(state){
						case(-1):
								//send_mark
								//state=prev_state
								break;
						case(0): 
							   m = new Message(2,(channels.get(0)).id,state);
							   send_message(m,channels.get(0));
							   state_value.set(m.id,m.m);
							   state++;
						       break;
						case(1):m = new Message(4,(channels.get(0)).id,state);
						   		send_message(m,channels.get(0));
						   		state_value.set(m.id,m.m);
								 state++;
						default:
								if(buffer.size()==2)
								  termination = true;
							  break;
					}
				}
				
				this.buffer=this.channel_to_proc(this.buffer);
				this.print_buffer();
				System.out.println(state_value);
			} catch (InterruptedException | MalformedURLException | RemoteException
					| NotBoundException e) {
				e.printStackTrace();
			}
		}
		
		if(this.id == 2) {
			try {
				while(!termination) {
					Thread.sleep(100);
					switch(state){
						case(0): 
								termination = true;
							    break;
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}
}
