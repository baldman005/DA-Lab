import java.util.ArrayList;


public class Channel_buffer {
	public int channel_id,mark_id,seq;
	private ArrayList<Message> buffer = new ArrayList<Message>();
	
	public Channel_buffer( int channel_id, int mark_id, int seq){
		this.channel_id=channel_id;
		this.mark_id=mark_id;
		this.seq=seq;
	}
	
}
